package com.example.dicerollerbyimtiaz09;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import java.util.Random;

public class diceroller extends AppCompatActivity {

    private ImageView imgView1, imgView2;
    private Button btn;
    private final Random randNmbr = new Random();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_diceroller);

        imgView1 = findViewById(R.id.imageView1);
        imgView2 = findViewById(R.id.imageView2);
        btn = findViewById(R.id.btn3);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                rollDice();
            }
        });
    }

    private void rollDice() {
        int randomNumber1 = randNmbr.nextInt(6) + 1;
        int randomNumber2 = randNmbr.nextInt(6) + 1;

        if( randomNumber1 == 1 ){
            imgView1.setImageResource(R.drawable.dice1);
        }else if( randomNumber1 == 2 ){
            imgView1.setImageResource(R.drawable.dice2);
        }else if( randomNumber1 == 3 ){
            imgView1.setImageResource(R.drawable.dice3);
        }else if( randomNumber1 == 4 ){
            imgView1.setImageResource(R.drawable.dice4);
        }else if( randomNumber1 == 5 ){
            imgView1.setImageResource(R.drawable.dice5);
        }else if( randomNumber1 == 6 ){
            imgView1.setImageResource(R.drawable.dice6);
        }

        if( randomNumber2 == 1 ){
            imgView2.setImageResource(R.drawable.dice1);
        }else if( randomNumber2 == 2 ){
            imgView2.setImageResource(R.drawable.dice2);
        }else if( randomNumber2 == 3 ){
            imgView2.setImageResource(R.drawable.dice3);
        }else if( randomNumber2 == 4 ){
            imgView2.setImageResource(R.drawable.dice4);
        }else if( randomNumber2 == 5 ){
            imgView2.setImageResource(R.drawable.dice5);
        }else if( randomNumber2 == 6 ){
            imgView2.setImageResource(R.drawable.dice6);
        }


    }
}
